package main

import "fmt"

func main() {
	var precoDolar float32
	var quantDolar float32

	fmt.Println("Insira o valor do dolar:")
		fmt.Scan(&precoDolar)

	fmt.Println("Insira a quantidade de dolares:")
		fmt.Scan(&quantDolar)

	var convReais float32 = precoDolar * quantDolar

	fmt.Printf("Conversão em reais: R$%.2f", convReais)

}
