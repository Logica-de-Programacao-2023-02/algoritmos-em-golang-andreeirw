package main

import "fmt"

func main() {

	var base float32
	var altura float32

	fmt.Println("Insira o valor da base do retangulo:")
		fmt.Scan(&base)

	fmt.Println("Insira o valor da altura do retangulo:")
		fmt.Scan(&altura)

	var area float32 = base * altura

	fmt.Printf("area do retangulo: %.2f", area)
}
