package main

import "fmt"

func main() {
	var vet [4]int

	for i := 0; i < 4; i++ {
		fmt.Println("Insira um numero:")
		fmt.Scan(&vet[i])
	}

	var media float32 = float32(vet[0]+vet[1]+vet[2]+vet[3]) / 4

	fmt.Printf("Media dos números: %.2f", media)

}
