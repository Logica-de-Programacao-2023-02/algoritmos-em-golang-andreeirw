package main

import "fmt"

func main() {
	//exercicio1


	var nome string
	var idade int
	var peso int


	println("Insira o nome")
		fmt.Scan(&nome)

	println("Insira a idade")
		fmt.Scan(&idade)

	println("Insira o peso")
		fmt.Scan(&peso)

	fmt.Println("seu nome: " + nome)

	fmt.Printf("sua Idade: %d\n", idade)

	fmt.Printf("seu Peso: %d", peso)

}
